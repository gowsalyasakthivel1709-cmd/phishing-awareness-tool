/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import { AnalysisResult, KeywordFinding, LinkFinding, SpellingFinding, ScamPatternFinding, BehavioralTrigger } from './src/types.js';

// Load environment variables
dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Initialize Gemini SDK with named parameters as required by the system skill
let ai: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  try {
    ai = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
    console.log("Gemini API Client successfully initialized.");
  } catch (err) {
    console.error("Failed to initialize Gemini API client:", err);
  }
} else {
  console.log("No GEMINI_API_KEY environment variable found. Advanced AI analysis will fallback to Heuristics.");
}

// ----------------------------------------------------------------------
// Local Heuristics Logic
// ----------------------------------------------------------------------
function analyzeHeuristics(content: string): AnalysisResult {
  const text = content || "";
  const textLower = text.toLowerCase();
  
  const keywordsDetected: KeywordFinding[] = [];
  const linksDetected: LinkFinding[] = [];
  const spellingErrorsList: SpellingFinding[] = [];
  const scamPatterns: ScamPatternFinding[] = [];
  const behavioralTriggers: BehavioralTrigger[] = [];
  
  let score = 0;

  // 1. Keyword analysis & scoring
  const rules = [
    { keyword: "verify account", category: "Account Security", text: "verify account", desc: "Asks user to re-authenticate or confirm credentials.", weight: 15 },
    { keyword: "confirm identity", category: "Account Security", text: "confirm identity", desc: "Common tactic to harvest account credentials.", weight: 15 },
    { keyword: "unauthorized access", category: "Security Alert", text: "unauthorized access", desc: "Imitation of security alerts to shock the victim.", weight: 12 },
    { keyword: "security breach", category: "Security Alert", text: "security breach", desc: "Fear-inducing notification indicating fake compromise.", weight: 12 },
    { keyword: "urgent", category: "Urgency", text: "urgent", desc: "Imposes synthetic scarcity or quick action demand.", weight: 10 },
    { keyword: "immediate action", category: "Urgency", text: "immediate action", desc: "Rushes cognitive analysis, preventing careful review.", weight: 10 },
    { keyword: "suspended", category: "Account Restriction", text: "suspended", desc: "Creates threat of service denial to prompt actions.", weight: 15 },
    { keyword: "restricted", category: "Account Restriction", text: "restricted", desc: "Claims account locked to trick users into resolving online.", weight: 15 },
    { keyword: "win prize", category: "Financial/Greed", text: "win prize", desc: "Classic greed hook used to trigger user engagement.", weight: 18 },
    { keyword: "won lottery", category: "Financial/Greed", text: "won lottery", desc: "Promises fake sweepstakes payout.", weight: 20 },
    { keyword: "million dollars", category: "Financial/Greed", text: "million dollars", desc: "Typical high-value bait in Nigerian Prince/advance-fee fraud.", weight: 20 },
    { keyword: "bank details", category: "Credential Request", text: "bank details", desc: "Direct attempt to grab structural banking info.", weight: 20 },
    { keyword: "click here", category: "Action Solicitation", text: "click here", desc: "Call to action masking malicious URLs.", weight: 8 },
    { keyword: "password reset", category: "Credential Request", text: "password reset", desc: "Often spoofs system reset utilities.", weight: 10 },
    { keyword: "update card", category: "Financial Request", text: "update card", desc: "Fraudulent credit card collection trick.", weight: 18 },
    { keyword: "tax refund", category: "Financial Request", text: "tax refund", desc: "IRS/HMRC tax scam impersonating governmental payouts.", weight: 15 },
    { keyword: "parcel delivery", category: "Logistics Scam", text: "parcel delivery", desc: "Spoofs shipment alerts (e.g. USPS, DHL) to harvest details.", weight: 12 },
    { keyword: "dhl status", category: "Logistics Scam", text: "dhl status", desc: "Fake tracking alerts.", weight: 12 },
  ];

  rules.forEach((rule) => {
    if (textLower.includes(rule.text)) {
      keywordsDetected.push({
        keyword: rule.keyword,
        category: rule.category,
        description: rule.desc
      });
      score += rule.weight;
    }
  });

  // 2. Link Detection (Regex)
  // Extracts any URLs (naked, http, https, domains)
  const urlRegex = /(https?:\/\/[^\s]+|www\.[^\s]+|[a-zA-Z0-9-]+\.[a-zA-Z0-9-]{2,}(?:\/[^\s]*)?)/gi;
  const matches = text.match(urlRegex) || [];
  const uniqueMatches = Array.from(new Set(matches)).slice(0, 8); // Max 8 unique links to show

  uniqueMatches.forEach((m) => {
    const url = m;
    let domain = "";
    try {
      // Basic domain derivation
      let cleanUrl = url;
      if (!url.startsWith('http://') && !url.startsWith('https://')) {
        cleanUrl = 'http://' + url;
      }
      const parsed = new URL(cleanUrl);
      domain = parsed.hostname;
    } catch {
      domain = url.split('/')[0];
    }

    const flags: string[] = [];
    let isSuspicious = false;

    // Flag rules
    if (url.startsWith('http://')) {
      flags.push("Unencrypted Connection (HTTP instead of HTTPS)");
      isSuspicious = true;
      score += 8;
    }

    // IP address checks
    const ipRegex = /^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$/;
    if (ipRegex.test(domain)) {
      flags.push("Numerical IP Address URL instead of domain name (Highly suspicious for financial/brand spoofing)");
      isSuspicious = true;
      score += 25;
    }

    // Typosquatting checks (paypal/google/netflix/amazon/bank spoof typos)
    const lowerDomain = domain.toLowerCase();
    const targets = ['paypal', 'google', 'netflix', 'amazon', 'microsoft', 'chase', 'apple', 'facebook'];
    targets.forEach((target) => {
      // If it contains the target but has weird typos or subdomains
      if (lowerDomain.includes(target)) {
        // e.g. paypa1.com, secure-paypal.com, login.paypal.com.scam-host.ua
        const isOfficial = lowerDomain === `${target}.com` || lowerDomain.endsWith(`.${target}.com`) || lowerDomain === `${target}.net` || lowerDomain.endsWith(`.${target}.net`);
        if (!isOfficial) {
          flags.push(`Potential Brand Typosquatting of ${target.toUpperCase()} (Contains brand keyword in an unauthorized subdomain or domain structure)`);
          isSuspicious = true;
          score += 20;
        }
      }
    });

    // Check for malicious top level domains commonly used by phishers
    const maliciousTLDs = ['.ru', '.cn', '.cc', '.info', '.top', '.xyz', '.work', '.gq', '.cf', '.tk', '.ga'];
    maliciousTLDs.forEach((tld) => {
      if (lowerDomain.endsWith(tld)) {
        flags.push(`Deceptive or Low-Cost Top Level Domain (${tld}) often abused by high-volume malicious campaigns`);
        isSuspicious = true;
        score += 10;
      }
    });

    // Subdomain crowding
    const subdomainPartsCount = domain.split('.').length;
    if (subdomainPartsCount >= 4) {
      flags.push(`Excessive Subdomains (${subdomainPartsCount}). Often designed to push the real domain end-address past screen limits on mobile devices.`);
      isSuspicious = true;
      score += 12;
    }

    if (isSuspicious) {
      linksDetected.push({
        url,
        domain,
        isSuspicious,
        flags
      });
    } else {
      // Still list it but mark as low or caution
      linksDetected.push({
        url,
        domain,
        isSuspicious: false,
        flags: ["Valid general formatting. Verification of actual registry owner is still advised."]
      });
    }
  });

  // 3. Spelling & Grammar Analysis (Heuristic Common Typos in Scam templates)
  const commonScamSpellingErrors = [
    { word: "verifyed", suggestion: "verified", reason: "Phishing emails often employ offshore operators or deliberately bypass spam filters using misspellings." },
    { word: "payement", suggestion: "payment", reason: "Incorrect orthography is highly characteristic of non-authentic brand emails." },
    { word: "recieved", suggestion: "received", reason: "Standard grammatical or typos slip past automated tools but stand out as organizational triggers." },
    { word: "custome", suggestion: "customer", reason: "Low professional copy standards indicate spoofing." },
    { word: "securit", suggestion: "security", reason: "Broken characters or typo bypass for spam scanning." },
    { word: "morgage", suggestion: "mortgage", reason: "Spelling mistakes in financial headers denote a fake." },
    { word: "imediate", suggestion: "immediate", reason: "Urgency spelling error." },
    { word: "suspention", suggestion: "suspension", reason: "Common grammatical error in threat campaigns." },
    { word: "unusuals", suggestion: "unusual", reason: "Incorrect pluralization indicating machine or amateur translation." },
  ];

  commonScamSpellingErrors.forEach((err) => {
    // Regex for exact word to avoid false positives inside larger words
    const regex = new RegExp(`\\b${err.word}\\b`, 'i');
    if (regex.test(text)) {
      spellingErrorsList.push({
        word: err.word,
        suggestion: err.suggestion,
        reason: err.reason
      });
      score += 8;
    }
  });

  // Heuristic grammar patterns like ALL-CAPS screaming or Multiple exclamation points
  if (/[A-Z]{5,}\s+[A-Z]{5,}\s+[A-Z]{5,}/.test(text)) {
    scamPatterns.push({
      name: "Screaming Typography (ALL CAPS)",
      description: "Excessive capitalization is used to evoke high panic and immediate response.",
      threatLevel: "Medium"
    });
    score += 8;
  }

  if (/!!!|!{2,}/.test(text)) {
    scamPatterns.push({
      name: "Sensationalized Punctuation (!!!)",
      description: "Repeated exclamation marks designed to simulate extreme crisis, which is never used by official entities.",
      threatLevel: "Low"
    });
    score += 5;
  }

  // Generic Greetings detector
  const genericGreetings = [
    "dear customer", "dear user", "dear webmail user", "dear account holder",
    "dear member", "dear sir or madam", "dear client", "dear value customer", "dear valued customer"
  ];
  genericGreetings.forEach((greeting) => {
    if (textLower.includes(greeting)) {
      scamPatterns.push({
        name: "Generic/Non-Personalized Salutation",
        description: `Uses "${greeting}" instead of your real name. Authentic corporate entities have databases and will address you with your first/last name.`,
        threatLevel: "Medium"
      });
      score += 15;
    }
  });

  // 4. Behavioral and Deceptive Triggers
  if (textLower.includes("urgent") || textLower.includes("immediate") || textLower.includes("within 24") || textLower.includes("expires")) {
    behavioralTriggers.push({
      name: "Urgency & Scarcity",
      severity: "High",
      description: "Creating a countdown or short deadline to bypass the victim's rational analysis and prompt reckless compliance."
    });
  }

  if (textLower.includes("suspend") || textLower.includes("restrict") || textLower.includes("block") || textLower.includes("unauthorized")) {
    behavioralTriggers.push({
      name: "Fear & Loss Avoidance",
      severity: "High",
      description: "Threatening account deletion, law enforcement intervention, or financial penalties to induce compliance."
    });
  }

  if (textLower.includes("reward") || textLower.includes("won") || textLower.includes("lottery") || textLower.includes("prize") || textLower.includes("gift card")) {
    behavioralTriggers.push({
      name: "Greed & Opportunity",
      severity: "Medium",
      description: "Exploiting the desire for unexpected wealth or rewards to gain sensitive access or custom advanced fees."
    });
  }

  if (textLower.includes("bank") || textLower.includes("irs") || textLower.includes("security department") || textLower.includes("it support") || textLower.includes("chief executive")) {
    behavioralTriggers.push({
      name: "Authority & Mimicry",
      severity: "Medium",
      description: "Impersonating powerful offices, IT support, tax authorities, or banks to pressure individuals who typically respect hierarchy."
    });
  }

  if (behavioralTriggers.length === 0) {
    behavioralTriggers.push({
      name: "Mild Social Engineering",
      severity: "Low",
      description: "Passive language offering assistance or updates to build gradual trust before requesting sensitive assets."
    });
  }

  // Adjust score constraints
  score = Math.min(100, score);
  if (score < 10) score = 15; // default minimal risk baseline for scanning any message

  let riskLevel: 'Low' | 'Medium' | 'High' = 'Low';
  if (score >= 45 && score < 75) {
    riskLevel = 'Medium';
  } else if (score >= 75) {
    riskLevel = 'High';
  }

  // Recommendations generator
  const recommendations: string[] = [
    "Verify the sender's actual email address context by clicking 'Details' in your mail provider; do not rely on the simple Display Name.",
    "Do not click any embedded links or download attachments from this message directly.",
    "Log in to your respective account directly through a trusted bookmark or typed URL in a clean tab - never link from the email.",
    "If claiming a service disruption, look up the service vendor's official phone number separately and call customer support to confirm."
  ];

  if (riskLevel === 'High') {
    recommendations.unshift("Report this incident immediately to your company's IT operations center or security officer.", "Immediately change your password if any credential was submitted already.");
  }

  // Overall text description
  let overallExplanation = "";
  if (riskLevel === 'High') {
    overallExplanation = "This analysis indicates a high probability of a targeted phishing or social engineering exploit. The email utilizes strong panic anchors, urgent call-to-actions, and generic greetings. Several typical scam flags have been isolated.";
  } else if (riskLevel === 'Medium') {
    overallExplanation = "This message contains moderate suspicious hallmarks of generic mass email scams, suspect keywords, or untethered links. While not explicitly destructive on its own, immediate caution and direct confirmation are recommended.";
  } else {
    overallExplanation = "Low density of explicit phishing vectors found by our rules. The email represents standard newsletters or direct notices, but we still suggest standard cyber-hygiene practices when clicking any link.";
  }

  return {
    score,
    riskLevel,
    keywordsDetected,
    linksDetected,
    spellingErrorsCount: spellingErrorsList.length,
    spellingErrorsList,
    scamPatterns,
    behavioralTriggers,
    overallExplanation,
    recommendations,
  };
}

// ----------------------------------------------------------------------
// Express Endpoints
// ----------------------------------------------------------------------

// API route 1: Local Heuristics
app.post('/api/analyze-local', (req, res) => {
  const { content } = req.body;
  if (!content) {
    return res.status(400).json({ error: "Missing 'content' body parameter" });
  }
  const result = analyzeHeuristics(content);
  return res.json(result);
});

// API route 2: Advanced Gemini AI analysis with schema output
app.post('/api/analyze-ai', async (req, res) => {
  const { content } = req.body;
  if (!content) {
    return res.status(400).json({ error: "Missing 'content' body parameter" });
  }

  if (!ai) {
    // Elegant fallback to Heuristics with flag
    console.log("No Gemini API client configured, falling back to heuristics parser instantly.");
    const result = analyzeHeuristics(content);
    return res.json({
      ...result,
      isFallback: true,
      fallbackMessage: "Heuristics used check. Configure GEMINI_API_KEY in Settings Secrets to activate Gemini Advanced AI Analysis."
    });
  }

  try {
    const prompt = `You are a Cybersecurity Phishing Analyst. Please analyze this message content for phishing attacks, suspect keywords, link threats, formatting red flags, spelling, social pressure triggers, and security recommendations.

Text Content to Analyze:
---
${content}
---

Provide a comprehensive threat assessment with educational details for a college cyber-safety presentation.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are an expert security engineer. You extract spam patterns and phishing vectors. You MUST respond strictly with high-quality JSON matches. Real-world parameters only. Do not lie or omit errors.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            score: {
              type: Type.INTEGER,
              description: "A calculated threat hazard level from 0 (perfectly safe newsletter/friend) to 100 (direct urgent phishing attack)"
            },
            riskLevel: {
              type: Type.STRING,
              description: "Must be 'Low' or 'Medium' or 'High' based on computed threat"
            },
            keywordsDetected: {
              type: Type.ARRAY,
              description: "Collection of suspicious, manipulative words or phrases isolated from the text",
              items: {
                type: Type.OBJECT,
                properties: {
                  keyword: { type: Type.STRING, description: "The exact matched word or close phrase" },
                  category: { type: Type.STRING, description: "E.g. Urgency, Financial Bait, Scarcity, Security Shock, Credential Request" },
                  description: { type: Type.STRING, description: "Educational cybersecurity reason why this word is considered bad in standard threat campaigns" }
                },
                required: ["keyword", "category", "description"]
              }
            },
            linksDetected: {
              type: Type.ARRAY,
              description: "List of extracted URLs/domains and why they are hazardous",
              items: {
                type: Type.OBJECT,
                properties: {
                  url: { type: Type.STRING, description: "The raw URL or apparent domain" },
                  domain: { type: Type.STRING, description: "Clean hostname extracted" },
                  isSuspicious: { type: Type.BOOLEAN, description: "Whether link is problematic" },
                  flags: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                    description: "Issues like HTTP only, typosquatting paypal features, multiple subdomains, IP addresses"
                  }
                },
                required: ["url", "domain", "isSuspicious", "flags"]
              }
            },
            spellingErrorsCount: { type: Type.INTEGER },
            spellingErrorsList: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  word: { type: Type.STRING, description: "The misspelled word" },
                  suggestion: { type: Type.STRING, description: "Correct term" },
                  reason: { type: Type.STRING, description: "Why spelling lapses are deliberate markers or common signs of malicious external actors" }
                },
                required: ["word", "suggestion", "reason"]
              }
            },
            scamPatterns: {
              type: Type.ARRAY,
              description: "Anatomies of scams e.g. generic greetings, missing corporate signs, or payment pressure",
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  description: { type: Type.STRING },
                  threatLevel: { type: Type.STRING, description: "'Low' | 'Medium' | 'High'" }
                },
                required: ["name", "description", "threatLevel"]
              }
            },
            behavioralTriggers: {
              type: Type.ARRAY,
              description: "Psychological principles used in social engineering used",
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING, description: "Urgency, Fear, Greed, Authority, Scarcity, Curiosity" },
                  severity: { type: Type.STRING, description: "'Low' | 'Medium' | 'High'" },
                  description: { type: Type.STRING, description: "Detailed look at the psychological vector applied" }
                },
                required: ["name", "severity", "description"]
              }
            },
            overallExplanation: {
              type: Type.STRING,
              description: "A highly clear summary explanation suited for an academic presentation"
            },
            recommendations: {
              type: Type.ARRAY,
              description: "List of defensive instructions",
              items: { type: Type.STRING }
            }
          },
          required: [
            "score", "riskLevel", "keywordsDetected", "linksDetected",
            "spellingErrorsCount", "spellingErrorsList", "scamPatterns",
            "behavioralTriggers", "overallExplanation", "recommendations"
          ]
        }
      }
    });

    const aiText = response.text;
    if (!aiText) {
      throw new Error("No response text back from Gemini");
    }

    const cleanResult = JSON.parse(aiText.trim());
    return res.json({
      ...cleanResult,
      isFallback: false
    });

  } catch (error: any) {
    console.error("Gemini AI Analysis crashed, generating local fallback...", error);
    const result = analyzeHeuristics(content);
    return res.json({
      ...result,
      isFallback: true,
      fallbackMessage: `AI engine experienced a runtime error. Reverting to local heuristics engine. (Error detail: ${error.message || error})`
    });
  }
});

// Serve static assets in production, otherwise boot Vite in dev mode.
async function initServer() {
  if (process.env.NODE_ENV === "production") {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[CyberSecurity Server] Operational at http://localhost:${PORT}`);
  });
}

initServer();
