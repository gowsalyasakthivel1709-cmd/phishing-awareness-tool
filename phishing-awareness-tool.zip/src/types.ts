/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface KeywordFinding {
  keyword: string;
  category: string;
  description: string;
}

export interface LinkFinding {
  url: string;
  domain: string;
  isSuspicious: boolean;
  flags: string[];
}

export interface SpellingFinding {
  word: string;
  suggestion: string;
  reason: string;
}

export interface ScamPatternFinding {
  name: string;
  description: string;
  threatLevel: 'Low' | 'Medium' | 'High';
}

export interface BehavioralTrigger {
  name: string; // e.g. "Urgency", "Fear", "Authority"
  severity: 'Low' | 'Medium' | 'High';
  description: string;
}

export interface AnalysisResult {
  score: number; // 0 to 100
  riskLevel: 'Low' | 'Medium' | 'High';
  keywordsDetected: KeywordFinding[];
  linksDetected: LinkFinding[];
  spellingErrorsCount: number;
  spellingErrorsList: SpellingFinding[];
  scamPatterns: ScamPatternFinding[];
  behavioralTriggers: BehavioralTrigger[];
  overallExplanation: string;
  recommendations: string[];
}

export interface QuizQuestion {
  id: number;
  scenario: string;
  sender: string;
  subject: string;
  body: string;
  options: { text: string; isCorrect: boolean }[];
  explanation: string;
  criticalIndicators: string[];
}
