/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { SAMPLE_TEMPLATES, EmailTemplate } from './components/SampleTemplates.js';
import QuizSection from './components/QuizSection.js';
import { AnalysisResult } from './types.js';
import { 
  Shield, 
  ShieldAlert, 
  AlertTriangle, 
  Mail, 
  Link2, 
  Sparkles, 
  RefreshCw, 
  Sliders,
  Database, 
  BookOpen, 
  Check, 
  CheckSquare, 
  Info, 
  ExternalLink, 
  ChevronRight, 
  Terminal, 
  Settings, 
  Play, 
  HelpCircle,
  Lightbulb,
  Lock,
  ListFilter,
  CheckCircle2,
  Menu,
  X,
  History,
  FileText,
  Award,
  ArrowRight,
  TrendingUp,
  Fingerprint
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface ScanHistoryItem {
  id: string;
  sender: string;
  subject: string;
  body: string;
  result: AnalysisResult;
  engine: 'local' | 'ai';
  score: number;
  risk: string;
  date: string;
}

export default function App() {
  // Navigation tabs matching the Sleek theme
  const [activeTab, setActiveTab] = useState<'analysis' | 'intel' | 'history' | 'training' | 'companion'>('analysis');
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);

  // Input states
  const [selectedTemplate, setSelectedTemplate] = useState<number>(-1);
  const [sender, setSender] = useState<string>("");
  const [subject, setSubject] = useState<string>("");
  const [body, setBody] = useState<string>("");
  
  // Analyzer settings
  const [engineMode, setEngineMode] = useState<'local' | 'ai'>('local');
  const [presenterName, setPresenterName] = useState<string>("Student Presenter");
  const [isEditingPresenter, setIsEditingPresenter] = useState<boolean>(false);
  
  // API Call States
  const [loading, setLoading] = useState<boolean>(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  
  // Dynamic checklist progress
  const [completedItems, setCompletedItems] = useState<Record<number, boolean>>({});

  // History Tracker with full snapshots for interactive retrieval
  const [analysesHistory, setAnalysesHistory] = useState<ScanHistoryItem[]>([]);

  // Load sample template on initiation
  useEffect(() => {
    loadTemplate(0);
  }, []);

  const loadTemplate = (idx: number) => {
    if (idx >= 0 && idx < SAMPLE_TEMPLATES.length) {
      const temp = SAMPLE_TEMPLATES[idx];
      setSelectedTemplate(idx);
      setSender(temp.sender);
      setSubject(temp.subject);
      setBody(temp.content);
      setResult(null);
      setErrorMsg(null);
      setCompletedItems({});
    }
  };

  const triggerAnalysis = async () => {
    if (!body.trim()) {
      setErrorMsg("Please paste some email message content first.");
      return;
    }

    setLoading(true);
    setErrorMsg(null);
    setResult(null);
    setCompletedItems({});

    const endpoint = engineMode === 'ai' ? '/api/analyze-ai' : '/api/analyze-local';
    
    // Combine subject and body to give full lexical depth for the model or heuristic rules
    const combinedContent = `Subject: ${subject}\nSender: ${sender}\n\n${body}`;

    try {
      const response = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: combinedContent }),
      });

      if (!response.ok) {
        throw new Error(`Server returned HTTP state ${response.status}`);
      }

      const data: AnalysisResult = await response.json();
      setResult(data);
      
      // Save item detailed snapshot to session history
      const logItem: ScanHistoryItem = {
        id: crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 9),
        sender,
        subject: subject || "Untitled Query",
        body,
        result: data,
        engine: engineMode,
        score: data.score,
        risk: data.riskLevel,
        date: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
      };
      
      setAnalysesHistory(prev => [logItem, ...prev].slice(0, 10));

    } catch (err: any) {
      console.error("Analysis network error:", err);
      setErrorMsg(`An error occurred while calling the endpoint: ${err.message || err}. Ensuring heuristics is available.`);
    } finally {
      setLoading(false);
    }
  };

  const loadHistoryItem = (item: ScanHistoryItem) => {
    setSender(item.sender);
    setSubject(item.subject);
    setBody(item.body);
    setResult(item.result);
    setEngineMode(item.engine);
    setCompletedItems({});
    setActiveTab('analysis');
    setMobileMenuOpen(false);
  };

  // Highlights suspect parts dynamically in the simulated email sandbox
  const renderHighlightedBody = () => {
    if (!result) return <p className="whitespace-pre-wrap">{body}</p>;

    const itemsToHighlight: Array<{ text: string; type: 'keyword' | 'link' | 'spelling'; description: string }> = [];

    // Collect keywords
    result.keywordsDetected.forEach(kw => {
      itemsToHighlight.push({
        text: kw.keyword,
        type: 'keyword',
        description: `[Keywords: ${kw.category}] - ${kw.description}`
      });
    });

    // Collect links
    result.linksDetected.forEach(link => {
      itemsToHighlight.push({
        text: link.url,
        type: 'link',
        description: `[URL Audit] Domain: ${link.domain}. Flags: ${link.flags.join(', ')}`
      });
    });

    // Collect spelling errors
    result.spellingErrorsList.forEach(spell => {
      itemsToHighlight.push({
        text: spell.word,
        type: 'spelling',
        description: `[Linguistic Typos] Suggestion: ${spell.suggestion}. ${spell.reason}`
      });
    });

    // Sort items by text length descending so we don't break sub-strings during replacement
    itemsToHighlight.sort((a, b) => b.text.length - a.text.length);

    interface TextSegment {
      text: string;
      isHighlighted: boolean;
      type?: 'keyword' | 'link' | 'spelling';
      description?: string;
    }

    let segments: TextSegment[] = [{ text: body, isHighlighted: false }];

    // Iteratively split segments for each highlight target
    itemsToHighlight.forEach(target => {
      const nextSegments: TextSegment[] = [];
      const len = target.text.length;
      if (len === 0) return;

      segments.forEach(seg => {
        if (seg.isHighlighted) {
          nextSegments.push(seg);
          return;
        }

        const lowerText = seg.text.toLowerCase();
        const lowerTarget = target.text.toLowerCase();
        let startIdx = lowerText.indexOf(lowerTarget);

        if (startIdx === -1) {
          nextSegments.push(seg);
          return;
        }

        let currentText = seg.text;
        while (startIdx !== -1) {
          const before = currentText.substring(0, startIdx);
          const matched = currentText.substring(startIdx, startIdx + len);
          currentText = currentText.substring(startIdx + len);

          if (before) {
            nextSegments.push({ text: before, isHighlighted: false });
          }

          nextSegments.push({
            text: matched,
            isHighlighted: true,
            type: target.type,
            description: target.description
          });

          const lowerCurrent = currentText.toLowerCase();
          startIdx = lowerCurrent.indexOf(lowerTarget);
        }

        if (currentText) {
          nextSegments.push({ text: currentText, isHighlighted: false });
        }
      });

      segments = nextSegments;
    });

    return (
      <div className="whitespace-pre-wrap leading-relaxed font-sans text-sm text-slate-300">
        {segments.map((seg, i) => {
          if (!seg.isHighlighted) {
            return <span key={i}>{seg.text}</span>;
          }

          let colorClass = "bg-yellow-500/20 text-yellow-300 border-b-2 border-yellow-500/60";
          let badgeText = "FLAG";

          if (seg.type === 'link') {
            colorClass = "bg-rose-500/20 text-rose-300 border-b-2 border-rose-500/60 cursor-pointer";
            badgeText = "SUSPECT LINK";
          } else if (seg.type === 'spelling') {
            colorClass = "bg-amber-500/20 text-amber-300 border-b-2 border-dashed border-amber-500/60";
            badgeText = "TYPO";
          } else if (seg.type === 'keyword') {
            colorClass = "bg-[#a855f7]/20 text-[#d8b4fe] border-b-2 border-[#c084fc]";
            badgeText = "TRIGGER WORD";
          }

          return (
            <span
              key={i}
              className={`inline group relative p-0.5 rounded transition-colors ${colorClass}`}
              title={seg.description}
            >
              {seg.text}
              <span className="hidden group-hover:block absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-72 bg-slate-900 border border-slate-700/80 p-2.5 rounded-lg shadow-2xl text-xs text-white normal-case font-sans z-50 leading-normal">
                <span className="font-mono text-[9px] block text-rose-400 font-bold uppercase tracking-wider mb-1">
                  ⚠️ {badgeText} DETECTED
                </span>
                {seg.description}
              </span>
            </span>
          );
        })}
      </div>
    );
  };

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'High': return { text: 'text-rose-400', bg: 'bg-rose-500/10', border: 'border-rose-500/35', fill: '#f43f5e' };
      case 'Medium': return { text: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/35', fill: '#f59e0b' };
      default: return { text: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/35', fill: '#10b981' };
    }
  };

  const riskColors = result ? getRiskColor(result.riskLevel) : { text: 'text-slate-400', bg: 'bg-slate-500/10', border: 'border-slate-500/30', fill: '#64748b' };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex overflow-hidden font-sans">
      
      {/* Dynamic Glow Accents */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-blue-600/5 rounded-full blur-3xl pointer-events-none -z-10" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-purple-600/5 rounded-full blur-3xl pointer-events-none -z-10" />

      {/* Sidebar - Sleek Theme Layout Pattern */}
      <aside className="hidden md:flex w-64 border-r border-slate-800 bg-slate-900/40 flex-col shrink-0 z-20">
        <div className="p-6">
          
          {/* Logo Brand Header */}
          <div className="flex items-center gap-3 mb-8">
            <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center text-white shadow-lg shadow-blue-500/20">
              <Shield className="w-5 h-5" id="sidebar-shield-logo" />
            </div>
            <h1 className="font-bold text-lg tracking-tight text-white font-display">PHISHGUARD</h1>
          </div>

          {/* Navigation links matching theme names and behavior */}
          <nav className="space-y-1.5">
            <button
              onClick={() => setActiveTab('analysis')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'analysis'
                  ? 'bg-blue-600/10 text-blue-400 border border-blue-500/30 font-bold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <Terminal className="w-4 h-4" />
              Analysis Tool
            </button>

            <button
              onClick={() => setActiveTab('intel')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'intel'
                  ? 'bg-blue-600/10 text-blue-400 border border-blue-500/30 font-bold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <Fingerprint className="w-4 h-4" />
              Threat Intelligence
            </button>

            <button
              onClick={() => setActiveTab('history')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold transition-all relative ${
                activeTab === 'history'
                  ? 'bg-blue-600/10 text-blue-400 border border-blue-500/30 font-bold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <History className="w-4 h-4" />
              Scan History
              {analysesHistory.length > 0 && (
                <span className="absolute right-2 px-1.5 py-0.2 bg-blue-500 text-white text-[9px] font-mono font-bold rounded-full">
                  {analysesHistory.length}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('training')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'training'
                  ? 'bg-blue-600/10 text-blue-400 border border-blue-500/30 font-bold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <Award className="w-4 h-4" />
              Security Training
            </button>

            <button
              onClick={() => setActiveTab('companion')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'companion'
                  ? 'bg-blue-600/10 text-blue-400 border border-blue-500/30 font-bold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              Presenter Companion
            </button>
          </nav>

        </div>

        {/* Pro version badge bottom of sidebar */}
        <div className="mt-auto p-6 border-t border-slate-900">
          <div className="bg-blue-950/20 p-4 rounded-xl border border-blue-900/20 space-y-2">
            <div className="flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-blue-400" />
              <p className="text-xs font-bold text-blue-400 uppercase tracking-wider">PHISHGUARD PRO</p>
            </div>
            <p className="text-[10px] text-slate-400 leading-normal">
              Dual Heuristic / LLM analysis models configured. Safe sandbox active.
            </p>
          </div>
        </div>
      </aside>

      {/* Main Container */}
      <main className="flex-1 flex flex-col min-w-0 h-screen overflow-hidden">
        
        {/* Header - Sleek Design Block */}
        <header className="h-16 border-b border-slate-900 flex items-center justify-between px-6 bg-slate-950/80 backdrop-blur-md shrink-0">
          <div className="flex items-center gap-4">
            
            {/* Mobile Open Button */}
            <button
              onClick={() => setMobileMenuOpen(true)}
              className="md:hidden p-1 bg-slate-900 rounded border border-slate-800 text-slate-400"
            >
              <Menu className="w-5 h-5" />
            </button>

            {/* Status indicator pill */}
            <div className="flex items-center gap-2 bg-slate-900/80 border border-slate-800 px-3 py-1 rounded-full">
              <span className="text-[10px] font-mono text-slate-500">SYSTEM STATUS:</span>
              <span className="flex h-1.5 w-1.5 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500"></span>
              </span>
              <span className="text-[10px] font-mono text-emerald-400 uppercase font-semibold">Active & Shielded</span>
            </div>
          </div>

          {/* Presenter Profile settings Box */}
          <div className="flex items-center gap-4 text-xs">
            <div className="bg-slate-900/60 border border-slate-850 px-3 py-1.5 rounded-lg flex items-center gap-2">
              <span className="text-slate-500 font-mono text-[10px]">PRESENTER:</span>
              {isEditingPresenter ? (
                <input
                  type="text"
                  value={presenterName}
                  onChange={(e) => setPresenterName(e.target.value)}
                  onBlur={() => setIsEditingPresenter(false)}
                  onKeyDown={(e) => e.key === 'Enter' && setIsEditingPresenter(false)}
                  className="bg-slate-950 border-b border-blue-500 text-blue-300 font-semibold focus:outline-none w-32 py-0 px-1 font-sans text-xs"
                  autoFocus
                />
              ) : (
                <span 
                  onClick={() => setIsEditingPresenter(true)} 
                  className="font-semibold text-slate-200 cursor-pointer hover:text-blue-400 underline decoration-slate-700 hover:decoration-blue-400 underline-offset-2"
                >
                  {presenterName}
                </span>
              )}
            </div>

            <div className="w-8 h-8 rounded-full bg-blue-900/30 border border-blue-800 flex items-center justify-center text-blue-400 font-bold font-mono text-xs uppercase" title="Active student session">
              {presenterName ? presenterName.charAt(0) : "S"}
            </div>
          </div>
        </header>

        {/* Scrollable View Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 space-y-6">
          
          <AnimatePresence mode="wait">
            
            {/* View 1: Primary Email Analysis Tool */}
            {activeTab === 'analysis' && (
              <motion.div
                key="analysis-tab"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start"
              >
                
                {/* Left Side: Inputs and settings (7 columns count) */}
                <div className="lg:col-span-7 space-y-6">
                  
                  {/* Top quick description banner */}
                  <div className="bg-slate-900/30 border border-slate-900 rounded-2xl p-4 flex gap-3 text-xs leading-normal text-slate-400">
                    <Info className="w-4.5 h-4.5 text-blue-400 shrink-0 mt-0.5" />
                    <p>
                      Welcome to the PhishGuard laboratory interface. Input raw mail formats in the sandbox below or select predefined scam templates to dissect coercive engineering indicators instantly.
                    </p>
                  </div>

                  {/* Template quick selection row */}
                  <div className="space-y-2">
                    <span className="text-[10px] text-slate-400 font-mono block uppercase tracking-wider">Scam Template Library Presets:</span>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {SAMPLE_TEMPLATES.map((temp, i) => (
                        <button
                          key={i}
                          id={`preset-template-btn-${i}`}
                          onClick={() => loadTemplate(i)}
                          className={`px-3 py-2 rounded-xl text-left border text-[11px] font-sans transition-all flex flex-col justify-between h-16 ${
                            selectedTemplate === i
                              ? "bg-blue-600/10 border-blue-500 text-blue-300 font-semibold"
                              : "bg-slate-900/40 border-slate-800/80 hover:border-slate-800 text-slate-400 hover:text-slate-200"
                          }`}
                        >
                          <span className="truncate font-semibold text-slate-200 block w-full">{temp.name.split(' (')[0]}</span>
                          <span className="text-[9px] text-slate-500 font-mono truncate block w-full">{temp.category}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Raw inputs compartment */}
                  <div className="bg-slate-900/40 border border-slate-900 rounded-2xl p-5 space-y-4">
                    <div className="flex items-center gap-2 pb-2 border-b border-slate-900">
                      <Settings className="w-4 h-4 text-slate-400" />
                      <h3 className="font-bold text-xs sm:text-sm uppercase tracking-wider font-mono text-slate-300">Analyzer Payload Settings</h3>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <label className="text-[10px] text-slate-500 font-mono uppercase block">Mail sender display header:</label>
                        <input
                          type="text"
                          id="input-sender"
                          value={sender}
                          onChange={(e) => {
                            setSender(e.target.value);
                            setSelectedTemplate(-1);
                          }}
                          placeholder="e.g. PayPal Alert <service@paypa1-alert.com>"
                          className="w-full bg-slate-950/60 border border-slate-850 rounded-xl px-3.5 py-2 text-xs text-slate-200 font-mono focus:outline-none focus:border-blue-500/80"
                        />
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-[10px] text-slate-500 font-mono uppercase block">Subject description line:</label>
                        <input
                          type="text"
                          id="input-subject"
                          value={subject}
                          onChange={(e) => {
                            setSubject(e.target.value);
                            setSelectedTemplate(-1);
                          }}
                          placeholder="e.g. Account Restricted immediately!"
                          className="w-full bg-slate-950/60 border border-slate-850 rounded-xl px-3.5 py-2 text-xs text-slate-200 font-sans focus:outline-none focus:border-blue-500/80"
                        />
                      </div>
                    </div>

                    <div className="space-y-1.5 pt-2">
                      <label className="text-[10px] text-slate-500 font-mono uppercase flex justify-between">
                        <span>Pasted markup or email text payload:</span>
                        <span className="text-[9px] opacity-65">{body.length} char capacity</span>
                      </label>
                      <textarea
                        id="input-body-area"
                        value={body}
                        onChange={(e) => {
                          setBody(e.target.value);
                          setSelectedTemplate(-1);
                        }}
                        rows={10}
                        placeholder="Paste details of the email body text containing external links or threats here..."
                        className="w-full bg-slate-955 border border-slate-850 rounded-xl p-4 text-xs text-slate-300 font-mono focus:outline-none focus:border-blue-500/85 leading-relaxed resize-none"
                      />
                    </div>

                    {/* Choose strategy mode */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-3 border-t border-slate-900">
                      <div className="space-y-0.5">
                        <span className="text-[10px] text-slate-500 font-mono block uppercase">Forensic logic engine:</span>
                        <p className="text-[10px] text-slate-400">Select heuristic databases or advanced GenAI model logic.</p>
                      </div>

                      <div className="flex gap-2">
                        <button
                          onClick={() => setEngineMode('local')}
                          className={`px-3 py-1.5 rounded-lg text-xs font-semibold font-sans border transition-all flex items-center gap-1.5 cursor-pointer ${
                            engineMode === 'local'
                              ? "bg-slate-800 text-blue-400 border-blue-500/40"
                              : "bg-slate-950/50 border-slate-850 text-slate-400 hover:text-slate-300"
                          }`}
                        >
                          <Sliders className="w-3.5 h-3.5" />
                          Deterministic Heuristics
                        </button>
                        <button
                          onClick={() => setEngineMode('ai')}
                          className={`px-3 py-1.5 rounded-lg text-xs font-semibold font-sans border transition-all flex items-center gap-1.5 cursor-pointer ${
                            engineMode === 'ai'
                              ? "bg-blue-600 text-white border-blue-500"
                              : "bg-slate-950/50 border-slate-850 text-slate-400 hover:text-slate-300"
                          }`}
                        >
                          <Sparkles className="w-3.5 h-3.5" />
                          Gemini Cognitive AI
                        </button>
                      </div>
                    </div>

                  </div>

                  {/* Submission and Action Trigger bar */}
                  <div className="flex justify-end pt-2">
                    <button
                      id="analysis-trigger-action"
                      onClick={triggerAnalysis}
                      disabled={loading}
                      className={`px-8 py-3 bg-blue-600 hover:bg-blue-500 text-white text-xs sm:text-sm font-bold rounded-xl transition-all shadow-lg shadow-blue-500/10 hover:shadow-blue-500/20 flex items-center gap-2 cursor-pointer w-full sm:w-auto ${
                        loading ? "opacity-60 cursor-wait" : ""
                      }`}
                    >
                      {loading ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin" />
                          Decompressing Malicious Payload Indicators...
                        </>
                      ) : (
                        <>
                          <Play className="w-4 h-4" />
                          RUN SECURITY DISSECTION
                        </>
                      )}
                    </button>
                  </div>

                  {errorMsg && (
                    <div className="p-3.5 bg-rose-950/20 border border-rose-900/40 rounded-xl text-rose-400 text-xs flex items-start gap-2.5">
                      <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                      <span>{errorMsg}</span>
                    </div>
                  )}

                </div>

                {/* Right Side: Diagnosis Telemetry outputs (5 columns count) */}
                <div className="lg:col-span-5 space-y-6">
                  
                  {result ? (
                    <div className="space-y-6">
                      
                      {/* Risk Index Gauge Card */}
                      <div className="bg-slate-900/60 border border-slate-800/80 p-6 rounded-2xl shadow-xl relative overflow-hidden">
                        
                        {/* Status absolute label */}
                        <div className="flex items-center justify-between mb-4">
                          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono">Vulnerability Metric</h3>
                          <span className={`px-2 py-0.5 bg-red-950/60 font-bold font-mono text-[10px] rounded border ${riskColors.text} ${riskColors.border}`}>
                            {result.riskLevel} threat
                          </span>
                        </div>

                        <div className="flex items-center gap-6">
                          
                          {/* Left Gauge */}
                          <div className="relative w-24 h-24 flex items-center justify-center shrink-0">
                            <svg className="w-full h-full transform -rotate-90">
                              <circle cx="48" cy="48" r="38" className="stroke-slate-800" strokeWidth="6" fill="none" />
                              <motion.circle
                                cx="48"
                                cy="48"
                                r="38"
                                stroke={riskColors.fill}
                                strokeWidth="6"
                                fill="none"
                                strokeDasharray={239}
                                initial={{ strokeDashoffset: 239 }}
                                animate={{ strokeDashoffset: 239 - (239 * result.score) / 100 }}
                                transition={{ duration: 0.8 }}
                                strokeLinecap="round"
                              />
                            </svg>
                            <span className="absolute font-mono text-2xl font-extrabold text-white">{result.score}</span>
                          </div>

                          {/* Right summary explanations */}
                          <div className="space-y-1">
                            <span className="text-[10px] text-slate-500 font-mono block">Threat Index score:</span>
                            <p className="text-slate-300 text-xs leading-relaxed italic">
                              "{result.overallExplanation}"
                            </p>
                          </div>

                        </div>

                        {/* Linear Progress bar display */}
                        <div className="mt-4 pt-2 border-t border-slate-900">
                          <div className="flex justify-between text-[10px] font-mono text-slate-500 mb-1">
                            <span>0 Safe</span>
                            <span>Hazard Scale</span>
                            <span>100 Critical</span>
                          </div>
                          <div className="h-1.5 bg-slate-950 rounded-full overflow-hidden">
                            <motion.div
                              className="h-full rounded-full"
                              style={{ backgroundColor: riskColors.fill }}
                              initial={{ width: 0 }}
                              animate={{ width: `${result.score}%` }}
                              transition={{ duration: 0.6 }}
                            />
                          </div>
                        </div>

                      </div>

                      {/* Interactive sandbox mail preview window with highlight targets */}
                      <div className="bg-slate-900/60 rounded-2xl border border-slate-800 overflow-hidden">
                        
                        <div className="bg-slate-950 p-4 border-b border-slate-800/80 flex justify-between items-center">
                          <div className="flex items-center gap-2">
                            <div className="flex gap-1">
                              <span className="w-2 h-2 rounded-full bg-rose-500" />
                              <span className="w-2 h-2 rounded-full bg-amber-505 bg-amber-500" />
                              <span className="w-2 h-2 rounded-full bg-emerald-500" />
                            </div>
                            <span className="text-[10px] text-slate-400 font-mono">HOVER FORENSIC ACCENTS</span>
                          </div>
                          <span className="text-[9px] bg-blue-950 text-blue-400 border border-blue-900/40 font-mono px-2 rounded">
                            Interactive Sandbox
                          </span>
                        </div>

                        <div className="p-4 space-y-3 bg-slate-950/20">
                          <div className="text-[11px] text-slate-400 font-mono space-y-1 pb-3 border-b border-slate-900">
                            <div>Sender: <span className="text-slate-300 font-semibold select-all">{sender || "Undefined"}</span></div>
                            <div>Subject: <span className="text-slate-200 font-semibold">{subject || "Empty"}</span></div>
                          </div>

                          <div className="p-3 bg-slate-950/60 border border-slate-850 rounded-xl max-h-60 overflow-y-auto leading-relaxed relative">
                            {renderHighlightedBody()}
                          </div>

                          <span className="text-[9px] text-slate-500 font-mono block italic text-center">
                            Hover highlighted words to decode malicious social engineering patterns.
                          </span>
                        </div>

                      </div>

                      {/* Decoded indicators list */}
                      <div className="bg-slate-900/60 border border-slate-800/80 p-5 rounded-2xl space-y-4">
                        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono border-b border-slate-900 pb-2">
                          Extracted Security Threat Indicators
                        </h3>

                        <div className="space-y-3">
                          
                          {/* Alert: suspicious link list */}
                          {result.linksDetected.filter(l => l.isSuspicious).map((link, idx) => (
                            <div key={idx} className="p-3 bg-rose-500/10 border border-rose-900/20 rounded-lg flex items-start gap-2.5">
                              <Link2 className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                              <div className="text-xs">
                                <p className="font-bold text-rose-400 truncate">Suspicious Link: {link.domain}</p>
                                <p className="text-slate-400 text-[11px] mt-0.5 leading-relaxed">{link.flags[0]}</p>
                              </div>
                            </div>
                          ))}

                          {/* Alert: cognitive triggers list */}
                          {result.behavioralTriggers.map((trig, idx) => (
                            <div key={idx} className="p-3 bg-amber-500/10 border border-amber-900/20 rounded-lg flex items-start gap-2.5">
                              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                              <div className="text-xs">
                                <p className="font-bold text-amber-400">Psychological Vector: {trig.name}</p>
                                <p className="text-slate-400 text-[11px] mt-0.5 leading-relaxed">{trig.description}</p>
                              </div>
                            </div>
                          ))}

                          {/* Alert: manipulative keywords */}
                          {result.keywordsDetected.slice(0, 3).map((kw, idx) => (
                            <div key={idx} className="p-3 bg-slate-800/40 border border-slate-700/30 rounded-lg flex items-start gap-2.5">
                              <Terminal className="w-4 h-4 text-slate-300 shrink-0 mt-0.5" />
                              <div className="text-xs">
                                <p className="font-bold text-slate-300">manipulative language: "{kw.keyword}"</p>
                                <p className="text-slate-400 text-[11px] mt-0.5 leading-relaxed">{kw.description}</p>
                              </div>
                            </div>
                          ))}

                          {result.keywordsDetected.length === 0 && result.linksDetected.length === 0 && (
                            <p className="text-xs text-slate-500 italic text-center py-4">
                              No dangerous indicators matched. This message displays standard newsletter style.
                            </p>
                          )}

                        </div>
                      </div>

                      {/* Compliance Defense Checklist */}
                      <div className="bg-blue-600 p-6 rounded-2xl text-white shadow-lg shadow-blue-900/20 space-y-3">
                        <div className="flex items-center gap-2">
                          <CheckSquare className="w-5 h-5 shrink-0" />
                          <h3 className="font-bold text-sm">Security Recommendations Checklist</h3>
                        </div>
                        <ul className="text-xs space-y-2 opacity-95">
                          {result.recommendations.map((rec, i) => (
                            <li
                              key={i}
                              onClick={() => setCompletedItems(prev => ({ ...prev, [i]: !prev[i] }))}
                              className={`flex items-start gap-2 cursor-pointer transition-all select-none hover:translate-x-0.5 ${
                                completedItems[i] ? "line-through opacity-60 text-blue-200" : ""
                              }`}
                            >
                              <span className="shrink-0 mt-0.5">
                                {completedItems[i] ? "☑" : "☐"}
                              </span>
                              <span>{rec}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                    </div>
                  ) : (
                    <div className="bg-slate-900/30 border border-slate-900 rounded-2xl p-8 text-center flex flex-col items-center justify-center min-h-[400px]">
                      <Database className="w-10 h-10 text-slate-600 mb-4 animate-pulse" />
                      <h4 className="text-sm font-semibold text-slate-300 tracking-wide uppercase font-mono">Telemetry Standby</h4>
                      <p className="text-xs text-slate-500 max-w-xs mt-1.5 leading-relaxed">
                        Input an email payload inside the left text editor block and execute dissecting pipelines to view vulnerability logs.
                      </p>
                    </div>
                  )}

                </div>

              </motion.div>
            )}

            {/* View 2: Threat Intelligence Reference Tab */}
            {activeTab === 'intel' && (
              <motion.div
                key="intel-tab"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className="space-y-6"
              >
                <div className="bg-slate-900/60 border border-slate-800 p-6 rounded-2xl space-y-3">
                  <h2 className="text-lg font-bold font-display text-white">Social Engineering Attack Vector Dictionary</h2>
                  <p className="text-xs text-slate-400 leading-relaxed max-w-3xl">
                    Phishing succeeds not by hacking computer firewalls, but by hacking human neurology. In college cyber-safety presentations, we must emphasize these 5 critical social mechanisms used by bad actors.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  
                  <div className="bg-slate-900/30 border border-slate-905 border-slate-900 rounded-xl p-5 space-y-2">
                    <span className="px-2 py-0.5 bg-rose-500/10 text-rose-400 text-[10px] font-mono rounded font-bold uppercase">MECHANISM 1</span>
                    <h3 className="font-bold text-sm text-slate-100 font-display">Artificial Urgency & Time Constraints</h3>
                    <p className="text-xs text-slate-400 leading-relaxed font-sans">
                      By demanding action "within 24 hours" or claiming immediate "account holds", scammers force victims into a high-cognitive-load panic response state. This prevents them from opening extra browsers tabs or checking domain links calmly.
                    </p>
                    <div className="bg-slate-950 p-2 text-[10px] text-rose-300 font-mono rounded">
                      Typical Keywords: "Immediate action required", "Suspended", "Disruption notification"
                    </div>
                  </div>

                  <div className="bg-slate-900/30 border border-slate-900 rounded-xl p-5 space-y-2">
                    <span className="px-2 py-0.5 bg-amber-500/10 text-amber-400 text-[10px] font-mono rounded font-bold uppercase">MECHANISM 2</span>
                    <h3 className="font-bold text-sm text-slate-100 font-display">Authoritative Mimicry</h3>
                    <p className="text-xs text-slate-400 leading-relaxed font-sans">
                      Scammers pretend to speak for official IT departments, state tax departments (IRS), chief executives, or banking compliance centers. This exploits the standard human tendency to obey rules without checking display address credentials.
                    </p>
                    <div className="bg-slate-950 p-2 text-[10px] text-amber-300 font-mono rounded">
                      Typical Keywords: "Tax refund pending verifyed", "IT administrators notice", "Payment dispatch"
                    </div>
                  </div>

                  <div className="bg-slate-900/30 border border-slate-900 rounded-xl p-5 space-y-2">
                    <span className="px-2 py-0.5 bg-blue-500/10 text-blue-400 text-[10px] font-mono rounded font-bold uppercase">MECHANISM 3</span>
                    <h3 className="font-bold text-sm text-slate-100 font-display">Subdomain Crowding & Typosquatting</h3>
                    <p className="text-xs text-slate-400 leading-relaxed font-sans">
                      By registration of low-cost international domain extensions (.xyz, .cc, .top) and packing the subdomains with corporate tags, scammers conceal actual targets (e.g. <code>secure.paypal.com.verification-gateway.xyz</code> is in fact hosted on <code>verification-gateway.xyz</code>).
                    </p>
                    <div className="bg-slate-950 p-2 text-[10px] text-blue-300 font-mono rounded">
                      Example: http://secure-paypal-login.com.verifications-accounts.ru
                    </div>
                  </div>

                  <div className="bg-slate-900/30 border border-slate-900 rounded-xl p-5 space-y-2">
                    <span className="px-2 py-0.5 bg-purple-500/10 text-purple-400 text-[10px] font-mono rounded font-bold uppercase">MECHANISM 4</span>
                    <h3 className="font-bold text-sm text-slate-100 font-display">Linguistic Filter Avoidance</h3>
                    <p className="text-xs text-slate-400 leading-relaxed font-sans">
                      Intentionally misspelling words ("verifyed", "payement", "suspention") lets malicious operators bypass keyword filters inside enterprise spam scanners. It also weeds out detail-oriented recipients, leaving high-risk targets.
                    </p>
                    <div className="bg-slate-950 p-2 text-[10px] text-purple-300 font-mono rounded">
                      Example: "Unusuals payement has restricted card details"
                    </div>
                  </div>

                </div>

                <div className="bg-blue-600/15 border border-blue-600/30 rounded-2xl p-6 flex flex-col md:flex-row items-center justify-between gap-4">
                  <div className="space-y-1">
                    <h4 className="font-bold text-sm text-white">How PhishGuard Counteracts Social Engineering</h4>
                    <p className="text-xs text-slate-300 leading-relaxed max-w-2xl">
                      Our system extracts URLs, scans against numeric DNS layouts, detects linguistic bypass traps, checks key grammatical structures, and maps the results on an objective Threat Probability indicator.
                    </p>
                  </div>
                  <button
                    onClick={() => setActiveTab('analysis')}
                    className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 shrink-0 transition-all font-sans"
                  >
                    Go Back to Parser
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

              </motion.div>
            )}

            {/* View 3: Scan History Tab */}
            {activeTab === 'history' && (
              <motion.div
                key="history-tab"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className="space-y-6"
              >
                <div className="bg-slate-900/60 border border-slate-800 p-6 rounded-2xl space-y-1">
                  <h2 className="text-lg font-bold font-display text-white">Cybersecurity Lab Session Logs</h2>
                  <p className="text-xs text-slate-400 leading-relaxed max-w-3xl">
                    View previous analyses executed during this active browser lesson. You can click on any archived report card to reload its payload details into the primary analytical visualizer instantly.
                  </p>
                </div>

                {analysesHistory.length === 0 ? (
                  <div className="bg-slate-900/30 border border-slate-900 rounded-2xl p-12 text-center flex flex-col items-center justify-center">
                    <History className="w-12 h-12 text-slate-700 mb-4" />
                    <h4 className="text-sm font-semibold text-slate-300 uppercase tracking-wide font-mono">Logs Database Empty</h4>
                    <p className="text-xs text-slate-500 max-w-xs mt-1">
                      No analyses recorded yet inside this active session. Run forensic checks first in the scanner view.
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {analysesHistory.map((item) => {
                      const snapColors = getRiskColor(item.risk);
                      return (
                        <div
                          key={item.id}
                          onClick={() => loadHistoryItem(item)}
                          className="group bg-slate-900/40 hover:bg-slate-900 border border-slate-850 hover:border-blue-500/40 p-4 rounded-xl space-y-3 cursor-pointer transition-all hover:-translate-y-0.5"
                        >
                          <div className="flex justify-between items-start gap-3">
                            <div className="truncate">
                              <span className="text-[10px] text-slate-500 font-mono uppercase block">Subject Payload:</span>
                              <h4 className="font-bold text-sm text-slate-200 group-hover:text-blue-400 truncate font-sans">{item.subject}</h4>
                            </div>
                            <span className="text-[10px] text-slate-500 font-mono shrink-0 font-bold">{item.date}</span>
                          </div>

                          <div className="flex items-center justify-between text-xs font-mono pt-2 border-t border-slate-950/80">
                            <div>
                              <span className="text-slate-500 font-mono block text-[9px] uppercase">Analysis Strategy:</span>
                              <span className="text-slate-300 font-bold capitalize">{item.engine} engine</span>
                            </div>

                            <div className="text-right">
                              <span className="text-slate-500 font-mono block text-[9px] uppercase">Threat score:</span>
                              <span className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono leading-none ${snapColors.bg} ${snapColors.text} ${snapColors.border}`}>
                                {item.score} / 100 ({item.risk} Risk)
                              </span>
                            </div>
                          </div>

                          <div className="bg-slate-950/40 p-2.5 rounded font-mono text-[10px] text-slate-400 truncate">
                            Sender: {item.sender}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}

              </motion.div>
            )}

            {/* View 4: Security Training (Interactive Quiz Game) */}
            {activeTab === 'training' && (
              <motion.div
                key="training-tab"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
              >
                <QuizSection />
              </motion.div>
            )}

            {/* View 5: Presenter Outline & Companion Docs */}
            {activeTab === 'companion' && (
              <motion.div
                key="companion-tab"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className="space-y-6"
              >
                {/* Outliner block */}
                <div className="bg-slate-900/60 border border-slate-800 p-6 rounded-2xl relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/5 rounded-full blur-2xl pointer-events-none" />
                  
                  <div className="flex items-center gap-2.5 border-b border-slate-900 pb-4 mb-4">
                    <BookOpen className="w-5 h-5 text-indigo-400" />
                    <div>
                      <h3 className="font-bold text-white text-base font-sans">College Cybersecurity Presentation Reference Outline</h3>
                      <p className="text-xs text-slate-400">Technical documentation, structural flowcharts, and slide material for CS-Project lectures.</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs sm:text-sm">
                    
                    <div className="bg-slate-900/40 hover:bg-slate-900/60 transition-colors border border-slate-850 p-4 rounded-xl space-y-2">
                      <div className="flex items-center gap-1.5 font-bold text-slate-200 uppercase font-mono text-[11px] text-blue-400">
                        <span className="bg-blue-950 rounded px-1.5 py-0.5">01</span> Architecture Framework
                      </div>
                      <p className="text-slate-400 leading-relaxed text-[11px] sm:text-xs font-sans">
                        A modern full-stack single-page design. Serves static asset streams with **React & Vite** inside the browser. Backed by **Node.js Express** APIs hosting local recursive lexical analyzers and server-side **Google GenAI (Gemini-3.5-Flash)** REST operations.
                      </p>
                    </div>

                    <div className="bg-slate-900/40 hover:bg-slate-900/60 transition-colors border border-slate-850 p-4 rounded-xl space-y-2">
                      <div className="flex items-center gap-1.5 font-bold text-slate-200 uppercase font-mono text-[11px] text-indigo-400">
                        <span className="bg-indigo-950 rounded px-1.5 py-0.5">02</span> Double-Engine Design
                      </div>
                      <p className="text-slate-400 leading-relaxed text-[11px] sm:text-xs font-sans">
                        By layering two independent parsing methodologies, the application showcases defense-in-depth:
                        <br/>
                        <strong>1. Deterministic</strong>: Regex patterns for links, structural spam greetings, and static catalogs.
                        <br/>
                        <strong>2. Cognitive</strong>: LLMs parsing intent, urgency gradients, and context bypass tactics.
                      </p>
                    </div>

                    <div className="bg-slate-900/40 hover:bg-slate-900/60 transition-colors border border-slate-850 p-4 rounded-xl space-y-2">
                      <div className="flex items-center gap-1.5 font-bold text-slate-200 uppercase font-mono text-[11px] text-emerald-400">
                        <span className="bg-emerald-950 rounded px-1.5 py-0.5">03</span> Social Engineering
                      </div>
                      <p className="text-slate-400 leading-relaxed text-[11px] sm:text-xs font-sans">
                        Most breaches bypass technical systems entirely, exploiting humans. This software demonstrates social mechanisms: **Scarcity** (immediate card holds), **Authority** (IRS refund notice claims), and **Loss Avoidance** (payment expiration holds).
                      </p>
                    </div>

                  </div>

                  {/* Running instruction panel */}
                  <div className="bg-[#020617] rounded-xl border border-slate-900 p-4 mt-6">
                    <span className="font-mono text-slate-400 uppercase font-semibold text-[10px] block mb-2 tracking-widest text-[#a855f7]">💡 LOCAL HOST DEVELOPMENT DEPLOYMENT MANUAL (Step-by-Step)</span>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-[11px] font-mono leading-relaxed text-slate-400">
                      <div className="space-y-1">
                        <span className="text-slate-300 font-bold block">1. DEPENDENCY SETUP:</span>
                        <code>$ npm install</code>
                        <p className="text-[10px] text-slate-500 font-sans mt-1">Installs React, Tailwind, Express, and Vite compiler bundlers.</p>
                      </div>
                      <div className="space-y-1">
                        <span className="text-slate-300 font-bold block">2. RUN DEVELOPMENT:</span>
                        <code>$ npm run dev</code>
                        <p className="text-[10px] text-slate-500 font-sans mt-1">Spins up Node.js tsx loader and serves pages locally on port 3000.</p>
                      </div>
                      <div className="space-y-1">
                        <span className="text-slate-300 font-bold block">3. BUILD PRODUCTION:</span>
                        <code>$ npm run build && npm start</code>
                        <p className="text-[10px] text-slate-500 font-sans mt-1">Runs high-utility bundling pipelines for fast web loads.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

          </AnimatePresence>

        </div>

        {/* Footer */}
        <footer className="border-t border-slate-900 bg-slate-950/40 py-6 px-6 text-center text-xs text-slate-500 font-sans shrink-0 mt-auto">
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-4">
            <div>
              <p>© {new Date().getFullYear()} PhishShield Threat Analytics. Constructed for Academic Cybersecurity Presentations.</p>
            </div>
            <div className="flex gap-4">
              <span className="hover:text-slate-400 cursor-help flex items-center gap-1"><Info className="w-3 h-3" /> NIST CSF Aligned</span>
              <span className="hover:text-slate-400 cursor-help flex items-center gap-1"><Lock className="w-3 h-3" /> Sandbox Environment Secure</span>
            </div>
          </div>
        </footer>

      </main>

      {/* Mobile Drawer Navigation Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 md:hidden flex justify-end"
          >
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", bounce: 0, duration: 0.3 }}
              className="w-72 bg-slate-900 h-full border-l border-slate-800 p-6 flex flex-col"
            >
              <div className="flex justify-between items-center mb-8">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center text-white">
                    <Shield className="w-5 h-5" />
                  </div>
                  <h1 className="font-bold text-lg text-white font-display">PHISHGUARD</h1>
                </div>
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-1 bg-slate-800 rounded text-slate-400"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-2 flex-grow">
                <button
                  onClick={() => { setActiveTab('analysis'); setMobileMenuOpen(false); }}
                  className={`w-full flex items-center gap-3 px-3 py-3 rounded-lg text-xs font-semibold transition-all ${
                    activeTab === 'analysis' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:bg-slate-800/40'
                  }`}
                >
                  <Terminal className="w-4 h-4" />
                  Analysis Tool
                </button>

                <button
                  onClick={() => { setActiveTab('intel'); setMobileMenuOpen(false); }}
                  className={`w-full flex items-center gap-3 px-3 py-3 rounded-lg text-xs font-semibold transition-all ${
                    activeTab === 'intel' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:bg-slate-800/40'
                  }`}
                >
                  <Fingerprint className="w-4 h-4" />
                  Threat Intelligence
                </button>

                <button
                  onClick={() => { setActiveTab('history'); setMobileMenuOpen(false); }}
                  className={`w-full flex items-center gap-3 px-3 py-3 rounded-lg text-xs font-semibold transition-all ${
                    activeTab === 'history' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:bg-slate-800/40'
                  }`}
                >
                  <History className="w-4 h-4" />
                  Scan History
                </button>

                <button
                  onClick={() => { setActiveTab('training'); setMobileMenuOpen(false); }}
                  className={`w-full flex items-center gap-3 px-3 py-3 rounded-lg text-xs font-semibold transition-all ${
                    activeTab === 'training' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:bg-slate-800/40'
                  }`}
                >
                  <Award className="w-4 h-4" />
                  Security Training
                </button>

                <button
                  onClick={() => { setActiveTab('companion'); setMobileMenuOpen(false); }}
                  className={`w-full flex items-center gap-3 px-3 py-3 rounded-lg text-xs font-semibold transition-all ${
                    activeTab === 'companion' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:bg-slate-800/40'
                  }`}
                >
                  <BookOpen className="w-4 h-4" />
                  Presenter Companion
                </button>
              </div>

              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                <p className="text-[10px] font-mono text-blue-400 uppercase tracking-wider mb-1 font-bold">Pro Version Active</p>
                <p className="text-[9px] text-slate-400">Advanced cognitive LLM and heuristic analytical capabilities online.</p>
              </div>

            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
