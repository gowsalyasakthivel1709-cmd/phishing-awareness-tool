/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface EmailTemplate {
  name: string;
  sender: string;
  subject: string;
  category: string;
  content: string;
}

export const SAMPLE_TEMPLATES: EmailTemplate[] = [
  {
    name: "PayPal Account Hold (High Fear & Urgency)",
    sender: "PayPal Security <service-alert@paypa1-security-verification.com.ru>",
    subject: "Alert: Your PayPal account is currently restricted - Action Required!",
    category: "Financial / Fear Appeal",
    content: `Dear Customer,

We detected unusuals sign-in activity on your PayPal account. To ensure safety, your access has been temporarily restricted.

You must verify account immediately to re-enable your payments and card capabilities. Please update card and confirm identity by clicking below:

http://secure.paypal.com.login.verify-billing.xyz/account/recovery

If you do not click here to complete verification inside 24 hours, your account will be suspended permanently and remaining balances withheld.

Security Operations Division
PayPal Inc.`
  },
  {
    name: "IRS Tax Refund Notice (Greed / Bait)",
    sender: "IRS Direct Deposit Registry <refund-portal@government-tax-refund.top>",
    subject: "Immediate Notification: Your Tax Deposit of $1,420.55 is Pending Verifyed Status",
    category: "Financial Bait",
    content: `DEAR ACCOUNT HOLDER,

We are pleased to notify you that you are verifyed to receive a state tax refund of $1,420.55.

Due to a billing discrepancy or incorrect bank details, your previous direct deposit was rejected by our clearings house. To claim your tax refund safely, you must update login security keys.

ACT IMMEDIATELY to resolve this payement failure! Click here to login and verify bank details:

http://192.168.102.44/irs/refund-claims/process.html

Failure to verify account within 24 hours will result in permanent credit forfeiture and potential tax audit fees.

Internal Revenue Service
Department of the Treasury`
  },
  {
    name: "DHL Shipment Alert (Action Solicitation)",
    sender: "DHL Couriers Courier <delivery-status@dhl-express-logistics.cc>",
    subject: "Package Holding: Parcel delivery error for tracking #DHL-8840291",
    category: "Logistics Scam",
    content: `DHL status update:

Your parcel delivery is currently held at our terminal distribution center due to incomplete address details or missing payement of custom duties of $1.99.

To correct your tracking shipment details, please click here:
http://dhl.cargo-shipment-status.top/ref/login.php

Please provide your correct delivery location and credit details within 24 hours to schedule package arrival tomorrow morning.

Thank you,
Logistics Team
DHL Group`
  },
  {
    name: "Legitimate Corporate Newsletter (Safe Example)",
    sender: "Tech Education <weekly-digest@acme-university.edu>",
    subject: "Your Weekly Campus Cybersecurity Newsletter - June 2026",
    category: "Safe / Informational",
    content: `Dear Students and Staff,

Welcome to the summer semester weekly cybersecurity digest. 

We would like to remind everyone that our IT department will NEVER ask you for your password or verification codes via email. Always look out for suspicious links or mismatched domain extensions.

To view the university's full academic calendar and cybersecurity guidelines, please visit our official student portal:
https://portal.acme-university.edu/cybersecurity/hub

If you suspect any email of being a phishing attempt, please forward it to phishing-report@acme-university.edu.

Best regards,
IT Security Operations Team`
  }
];
