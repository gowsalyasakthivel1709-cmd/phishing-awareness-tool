/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { QuizQuestion } from '../types.js';
import { Shield, Sparkles, CheckCircle, AlertTriangle, ChevronRight, RotateCcw } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 1,
    scenario: "You receive an alarming security alert about a blocked login attempt on your corporate account.",
    sender: "Corporate IT Support <it-security@company-domain-verification.net>",
    subject: "CRITICAL: Urgent Password Reset Required - Blocked Intruder Warning",
    body: "An intruder from an overseas IP address attempted unauthorized access. Please update login credentials immediately to secure your files: http://company-domain-verification.net/auth-reset-page",
    options: [
      { text: "Reset password instantly to ensure the hacker does not lock you out.", isCorrect: false },
      { text: "Do not click. Reject link due to non-matching external domain and lack of HTTPS.", isCorrect: true }
    ],
    explanation: "This is standard authority coercion. The display name says 'Corporate IT' but the actual domain 'company-domain-verification.net' is an external typosquatted host. Real IT support has single sign-on mechanisms and would never send unencrypted raw HTTP forms.",
    criticalIndicators: [
      "Typosquatted domain extension (.net instead of trusted corporate .com)",
      "Unsecured connection protocol (http://)",
      "High urgency anxiety induction ('Intruder Warning')"
    ]
  },
  {
    id: 2,
    scenario: "An email claiming you won a sponsored lottery appears in your personal inbox.",
    sender: "Bonus Promotions Desk <awarded-compensation@bonus-awards.info>",
    subject: "Congratulations! You have been selected as the $5,000 cash prize winner!",
    body: "Dear valued customer, you have verifyed a payment deposit. Please download attachment and submit your physical address and bank details to claim payment.",
    options: [
      { text: "Ignore or delete. Authentic institutions do not give random large cash awards to un-entered lotteries and do not ask to download credentials.", isCorrect: true },
      { text: "Download the attachment, fill it in, but leave bank details blank just in case.", isCorrect: false }
    ],
    explanation: "This features typical 'Greed/Opportunity' lures. Promoters use generic greetings ('Dear valued customer') because they harvest thousands of emails. Downloading files can launch spyware or keyloggers.",
    criticalIndicators: [
      "Vague, generic greeting instead of personal name",
      "Requesting attachment download (potentially malicious executable script)",
      "Low cost .info Top Level Domain"
    ]
  },
  {
    id: 3,
    scenario: "Your bank alerts you that a transaction has put your card balance in negative digits.",
    sender: "Customer Security Operations <alert-response@192.168.4.15>",
    subject: "Important Transaction Alert: Fraudulent Payment Processing",
    body: "Dear Bank Member, a charge of $412.00 was recorded. If unauthorized, click here to authenticate verification: http://192.168.4.15/secure/balance-verify?id=99",
    options: [
      { text: "Click the text to secure funds and reverse the negative transaction immediately.", isCorrect: false },
      { text: "Close email, flag as phishing, and check your bank status directly from the official mobile app or phone bank service.", isCorrect: true }
    ],
    explanation: "Severe indicator alert: The sender address features a raw, local IP address ('192.168.4.15'). Legacy, legitimate banks would never expose numerical IPv4 addresses as external login gateways for customers.",
    criticalIndicators: [
      "Bare IPv4 numerical link instead of clear host domain",
      "Generic non-personal salutation ('Dear Bank Member')",
      "High-pressure financial fear hook"
    ]
  },
  {
    id: 4,
    scenario: "Your shipping status from a courier service is noted as 'Delivery Blocked'.",
    sender: "Express Dispatch Office <dispatch@couriers-express.ru>",
    subject: "Notice: Shipment hold. Payement error on package #US-8849-DX",
    body: "Dear customer, your shipping parcel delivery is restricted due to a missing payement of $1.50 custom tax. Please re-enter credentials immediately.",
    options: [
      { text: "It is only $1.50, so pay it to guarantee the delivery gets unblocked without delay.", isCorrect: false },
      { text: "Recognize 'payement' typos and Russian TLD (.ru) as major red flags. Look up official tracking elsewhere.", isCorrect: true }
    ],
    explanation: "Logistics scams leverage high volumes. Typos like 'payement' indicate translation machine copy or filter evasion. The Russian .ru extensions are statistically suspicious for US/Western courier services.",
    criticalIndicators: [
      "International Russian Top Level Domain (.ru) for western couriers",
      "Deliberate grammatical and spelling errors ('payement')",
      "Suspicious urgency to solve a fake minor fee"
    ]
  }
];

export default function QuizSection() {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [hasAnswered, setHasAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [quizFinished, setQuizFinished] = useState(false);

  const currentQuestion = QUIZ_QUESTIONS[currentIdx];

  const handleOptionClick = (optIdx: number) => {
    if (hasAnswered) return;
    setSelectedOption(optIdx);
    setHasAnswered(true);

    if (currentQuestion.options[optIdx].isCorrect) {
      setScore(prev => prev + 1);
    }
  };

  const handleNext = () => {
    setSelectedOption(null);
    setHasAnswered(false);
    if (currentIdx < QUIZ_QUESTIONS.length - 1) {
      setCurrentIdx(currentIdx + 1);
    } else {
      setQuizFinished(true);
    }
  };

  const resetQuiz = () => {
    setCurrentIdx(0);
    setSelectedOption(null);
    setHasAnswered(false);
    setScore(0);
    setQuizFinished(false);
  };

  return (
    <div className="bg-[#0f172a] rounded-2xl border border-blue-900/40 p-6 overflow-hidden relative" id="phishing-quiz-container">
      {/* Background glow effects */}
      <div className="absolute top-0 right-0 w-48 h-48 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-48 h-48 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="flex items-center justify-between mb-6 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-500/10 rounded-lg text-blue-400">
            <Shield className="w-5 h-5" id="quiz-shield-icon" />
          </div>
          <div>
            <h3 className="font-bold text-white text-lg font-sans">Interactive Quiz</h3>
            <p className="text-slate-400 text-xs">Test your Phishing Detection Skills</p>
          </div>
        </div>
        <div className="bg-slate-800/80 px-3 py-1 rounded-full text-xs text-blue-400 font-mono">
          Score: {score} / {QUIZ_QUESTIONS.length}
        </div>
      </div>

      {!quizFinished ? (
        <div>
          {/* Question context */}
          <div className="mb-4">
            <div className="flex justify-between text-xs text-slate-500 font-mono mb-2">
              <span>SCENARIO {currentQuestion.id} OF {QUIZ_QUESTIONS.length}</span>
              <span className="text-blue-400 font-medium">Spot the Trap</span>
            </div>
            <p className="text-slate-300 font-medium text-sm leading-relaxed">
              {currentQuestion.scenario}
            </p>
          </div>

          {/* Code/Email Box */}
          <div className="bg-[#020617] rounded-xl border border-slate-800/80 p-4 mb-5 font-mono text-xs">
            <div className="border-b border-slate-800/60 pb-2 mb-2 text-slate-400 space-y-1">
              <div><span className="text-slate-500">From:</span> {currentQuestion.sender}</div>
              <div><span className="text-slate-500">Subject:</span> {currentQuestion.subject}</div>
            </div>
            <div className="text-slate-300 whitespace-pre-wrap leading-relaxed py-1 bg-slate-900/20 p-2 rounded max-h-36 overflow-y-auto">
              {currentQuestion.body}
            </div>
          </div>

          {/* Options */}
          <div className="space-y-3">
            {currentQuestion.options.map((opt, idx) => {
              let btnStyle = "border-slate-850 hover:border-blue-800/60 hover:bg-slate-900/40 text-slate-300";
              let iconElement = null;

              if (hasAnswered) {
                if (opt.isCorrect) {
                  btnStyle = "border-emerald-500 bg-emerald-500/10 text-emerald-300";
                  iconElement = <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />;
                } else if (selectedOption === idx) {
                  btnStyle = "border-rose-500 bg-rose-500/10 text-rose-300";
                  iconElement = <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />;
                } else {
                  btnStyle = "opacity-45 border-slate-850 text-slate-500";
                }
              }

              return (
                <button
                  key={idx}
                  id={`quiz-option-button-${currentQuestion.id}-${idx}`}
                  disabled={hasAnswered}
                  onClick={() => handleOptionClick(idx)}
                  className={`w-full text-left p-3 rounded-xl border text-xs sm:text-sm font-sans flex items-center justify-between gap-3 transition-all duration-200 ${btnStyle}`}
                >
                  <span className="leading-relaxed">{opt.text}</span>
                  {iconElement}
                </button>
              );
            })}
          </div>

          {/* Quiz answer discussion / analysis findings */}
          <AnimatePresence>
            {hasAnswered && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="mt-5 p-4 bg-slate-900/90 rounded-xl border border-slate-800 space-y-3"
              >
                <div>
                  <div className="flex items-center gap-1 text-xs font-bold font-mono text-yellow-500 uppercase tracking-wider mb-1">
                    <Sparkles className="w-3.5 h-3.5" /> Correct Assessment
                  </div>
                  <p className="text-slate-300 text-xs sm:text-sm leading-relaxed font-sans">
                    {currentQuestion.explanation}
                  </p>
                </div>

                <div className="border-t border-slate-800/80 pt-2.5">
                  <span className="text-[10px] text-slate-500 font-mono block mb-1.5 uppercase tracking-wide">Threat Vectors Decoded:</span>
                  <div className="flex flex-wrap gap-1.5">
                    {currentQuestion.criticalIndicators.map((ind, i) => (
                      <span key={i} className="text-[10px] bg-rose-950/40 text-rose-300 border border-rose-900/30 px-2 py-0.5 rounded-full font-mono">
                        ⚠️ {ind}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="flex justify-end pt-1">
                  <button
                    id="quiz-next-question-button"
                    onClick={handleNext}
                    className="bg-blue-600 hover:bg-blue-500 text-white font-semibold py-1.5 px-4 rounded-lg text-xs flex items-center gap-1 font-sans transition-all"
                  >
                    {currentIdx < QUIZ_QUESTIONS.length - 1 ? "Next Scenario" : "View Results"}
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      ) : (
        <div className="text-center py-8">
          <div className="w-16 h-16 bg-blue-500/10 rounded-full flex items-center justify-center mx-auto mb-4 text-blue-400">
            <Shield className="w-8 h-8" />
          </div>
          <h4 className="text-xl font-bold text-white mb-2 font-sans">Quiz Completed!</h4>
          <p className="text-slate-400 text-xs sm:text-sm max-w-sm mx-auto mb-5 leading-relaxed font-sans">
            You scored <strong className="text-blue-400">{score} out of {QUIZ_QUESTIONS.length}</strong> correct threat identifications.
          </p>

          <div className="bg-[#020617] rounded-xl border border-slate-800 p-4 max-w-sm mx-auto mb-6 text-left">
            <span className="text-xs font-mono text-slate-500 block mb-1">YOUR CYBERSECURITY EXPOSURE:</span>
            {score === QUIZ_QUESTIONS.length ? (
              <p className="text-emerald-400 text-xs font-sans"><strong>Level 5 Secure (Expert Defender)</strong>: Superb vigilance. You consistently look past display names to evaluate domains and protocols.</p>
            ) : score >= 2 ? (
              <p className="text-amber-400 text-xs font-sans"><strong>Level 3 Restricted (Intermediate Guard)</strong>: Decent skills. Remember to always cross-check financial claims or short URLs before trusting labels.</p>
            ) : (
              <p className="text-red-400 text-xs font-sans"><strong>Level 1 Vulnerable (Critical Risk)</strong>: High vulnerability. You may be susceptible to urgency-themed brand impersonations. Keep practicing with our indicators panel!</p>
            )}
          </div>

          <button
            id="quiz-reset-button"
            onClick={resetQuiz}
            className="border border-slate-800 hover:border-slate-700 bg-slate-900/60 hover:bg-slate-900 text-slate-300 font-semibold py-2 px-5 rounded-xl text-xs flex items-center gap-1.5 mx-auto transition-all"
          >
            <RotateCcw className="w-3.5 h-3.5" /> Try Quiz Again
          </button>
        </div>
      )}
    </div>
  );
}
